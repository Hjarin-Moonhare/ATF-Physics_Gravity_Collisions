TF Physics 1.4 Preview
======================

TF Physics is the SFSE plugin that runs A-Body's body physics. This is all of it as its own mod, including the two-way
world collision I'm still building, so you can try it, test it or build on it.

WHAT'S IN IT
- Everything TF Physics 1.3 (in A-Body 1.5) does:
  - breast gravity from the chest's real tilt, with its own shape for each pose: lying on the back, on a side, face
    down, bent forward, on all fours;
  - every A-Body spring held to its 60 fps travel at any frame rate;
  - gravity inside the breast, belly and butt springs;
  - body-shape physics with the Variable presets: the body triangle and the part sliders scale each part's jiggle
    and gravity;
  - collisions: your arms, hands and thighs push your breasts, belly and glutes, the breasts push each other, and
    other characters push too.
- Dead bodies take part in the collisions too (1.3 leaves them out).
- A log every 5 seconds: Documents\My Games\Starfield\SFSE\Logs\TFPhysics.log.
- World collision, part one. A-Body's skeleton gets two invisible physics bodies, one per breast. TF Physics puts them
  on their own collision layer, where they touch nothing yet, and moves your character's two with your breasts every
  frame, through the game's own function for moving animated bodies (doors and lifts use it). They don't push
  anything yet: no items, no walls, no characters, so you shouldn't see a difference. Small loose items come next,
  then tables, walls and seats pushing back.

REQUIREMENTS
- A-Body 1.1.1 or newer
- SFSE 0.2.21 or newer
- Address Library for SFSE Plugins

INSTALL
Install it with your mod manager after A-Body, and let it win the conflicts on TFPhysics.dll, TFPhysics.ini and the
skeleton files. The installer asks two things:
1. Your body physics type, the same one you picked in A-Body:
   - Fixed presets: Realistic (Minimum), Low, Medium, High or Max. Body-shape physics off.
   - Variable presets: Realistic (Variable), Normal (Variable) or Max (Variable). Body-shape physics on.
2. How to install the skeleton:
   - Loose files (recommended): the two skeleton files as loose files. They beat any skeleton inside an archive, and
     another mod's loose skeleton as long as this mod wins the conflict. Starfield only uses loose files with
     bInvalidateOlderFiles=1 and sResourceDataDirsFinal= under [Archive] in StarfieldCustom.ini.
   - Archive: TF Physics.esm, an empty light plugin that needs A-Body.esm, and TF Physics - Main.ba2 with both
     skeleton files inside. Load TF Physics.esm after A-Body.esm and after any mod that brings its own female
     skeleton in an archive. A loose skeleton from another mod always beats it.

THE SKELETON
It's A-Body's own skeleton with the two invisible bodies added, so you don't need A-Body Skeleton next to it. Only one
female skeleton can win. With A-Body Skeleton winning, the physics run but world collision doesn't. With a skeleton
that doesn't have A-Body's bones (SF Extended Skeleton), A-Body's physics don't run.

CHECK THAT IT WORKS
Near the top of the log:
- "TF Physics (logging build: gravity, springs, body shape, collisions, world-collision proxies)"
- "Address Library: all 25 game addresses resolved through ..."
Then a summary every 5 s, and "world proxies" lines about your character's two invisible bodies.

TO GO BACK
Uninstall it: A-Body's own TF Physics, its settings and its skeleton come back.

FOR MODDERS
- The full source is a separate download, TF Physics source (MIT license): the plugin, the tests, the build scripts,
  and the docs, including what I read from the game and the hard risks. This DLL is that source's build.bat build.
- Every setting is in TFPhysics.ini, with what it does. [World] has the world-collision switches.
- proxy_skeleton_report.json (not installed) has the two invisible bodies' data: a 7.5 cm near-sphere on each breast,
  keyframed, on layer 62, and where each one sits on both skeletons.

FILES
- SFSE\Plugins\TFPhysics.dll: the full build (318,464 bytes, sha256 49d4a0b695dbb508...)
- SFSE\Plugins\TFPhysics.ini: A-Body's settings for your choice, plus [Collision], [Log] and [World]
- Loose: meshes\actors\human\characterassets\female\skeleton.nif and skeleton_facebones.nif (72,012 and
  77,848 bytes)
- Archive: TF Physics.esm (97 bytes) and TF Physics - Main.ba2 (45,638 bytes), the same two files
